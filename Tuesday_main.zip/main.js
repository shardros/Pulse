var BoardRouter = require('./scripts/boardRouter');
var SVG = require('./scripts/svg');
var B = require('./scripts/board');



